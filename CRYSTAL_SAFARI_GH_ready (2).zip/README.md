# CRYSTAL SAFARI — GitHub Pages Version

## 🇷🇺 Инструкция (русский)
1. Перейдите на [https://github.com](https://github.com) и создайте репозиторий с именем **CRYSTAL-SAFARI** (Public).
2. Загрузите файлы из этого архива (`index.html`, `style.css`, `README.md`).
3. В репозитории откройте **Settings → Pages**.
4. В разделе **Source** выберите:
   - Branch: `main`
   - Folder: `/ (root)`
5. Нажмите **Save**.
6. Через 1–2 минуты сайт станет доступен по адресу:  
   `https://ВАШ_ЛОГИН.github.io/CRYSTAL-SAFARI/`

---

## 🇬🇧 English Instructions
1. Go to [https://github.com](https://github.com) and create a new repository named **CRYSTAL-SAFARI** (Public).
2. Upload all files from this ZIP (`index.html`, `style.css`, `README.md`).
3. Go to **Settings → Pages**.
4. Under **Source**, select:
   - Branch: `main`
   - Folder: `/ (root)`
5. Click **Save**.
6. After 1–2 minutes, your site will be live at:  
   `https://YOUR_USERNAME.github.io/CRYSTAL-SAFARI/`
